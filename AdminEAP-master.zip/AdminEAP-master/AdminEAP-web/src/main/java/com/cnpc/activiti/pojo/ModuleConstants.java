package com.cnpc.activiti.pojo;

/**
 * Created by billJiang on 2017/7/4.
 * e-mail:475572229@qq.com  qq:475572229
 * 业务模块编码常量
 */
public class ModuleConstants {
    public final static String MODULE_VACATION="LEAVE";

    public final static String MODULE_TRAINING="TRAINING";

    public final static String MODULE_SCORE="SCORE";
}
