package com.cnpc.framework.query.entity;

public class Call {
	private String command;
	private String param;

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}
 
	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

}
