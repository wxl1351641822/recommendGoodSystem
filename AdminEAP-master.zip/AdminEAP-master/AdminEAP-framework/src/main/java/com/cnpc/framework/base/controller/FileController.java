package com.cnpc.framework.base.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by billJiang on 2017/3/5.
 * e-mail:475572229@qq.com  qq:475572229
 * 文件上传下载控制器,部分业务方法卸载UploaderController中
 */
@Controller
@RequestMapping(value="/file")
public class FileController {

}
