package com.cnpc.framework.activiti.service;

import com.cnpc.framework.base.service.BaseService;
import com.cnpc.framework.testng.BaseTest;

/**
 * Created by billJiang on 2017/6/21.
 * e-mail:475572229@qq.com  qq:475572229
 * 流程已办查询接口
 */
public interface HistoryPageService extends BaseService {
}
