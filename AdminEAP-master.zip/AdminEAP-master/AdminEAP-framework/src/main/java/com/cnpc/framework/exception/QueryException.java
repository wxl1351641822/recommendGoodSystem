package com.cnpc.framework.exception;

/**
 * Created by billJiang on 2017/1/18.
 * e-mail:jrn1012@petrochina.com.cn qq:475572229
 */
public class QueryException extends  Exception {
    public QueryException(String message) {
        super(message);
    }
}
