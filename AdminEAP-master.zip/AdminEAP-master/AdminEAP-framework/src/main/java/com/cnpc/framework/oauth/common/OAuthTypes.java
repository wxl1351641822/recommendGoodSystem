package com.cnpc.framework.oauth.common;

/**
 * Created by billJiang on 2017/1/15.
 * e-mail:jrn1012@petrochina.com.cn qq:475572229
 */
public class OAuthTypes {

    public static final String GITHUB="github";

    public static final String WEIXIN="weixin";

    public static final String QQ="qq";
}
