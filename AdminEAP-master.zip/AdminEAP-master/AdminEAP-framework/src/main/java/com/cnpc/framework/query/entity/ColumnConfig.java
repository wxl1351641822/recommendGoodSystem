package com.cnpc.framework.query.entity;


public class ColumnConfig {

    private Object[][] unSelected;

    private Object[][] selected;

    public Object[][] getUnSelected() {

        return unSelected;
    }

    public void setUnSelected(Object[][] unSelected) {

        this.unSelected = unSelected;
    }

    public Object[][] getSelected() {

        return selected;
    }

    public void setSelected(Object[][] selected) {

        this.selected = selected;
    }

}
