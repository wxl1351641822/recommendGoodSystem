package com.cnpc.framework.base.pojo;

import java.util.List;

public class CsvRow {
    private List<String> cols;

    public List<String> getCols() {
        return cols;
    }

    public void setCols(List<String> cols) {
        this.cols = cols;
    }

}
