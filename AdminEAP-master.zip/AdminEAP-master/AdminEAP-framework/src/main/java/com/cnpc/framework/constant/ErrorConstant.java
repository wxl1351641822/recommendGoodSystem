package com.cnpc.framework.constant;

/**
 * @author billjiang 475572229@qq.com
 * @create 18-2-24
 */
public class ErrorConstant {

    public final static String ERROR_DETAIL="如果不能解决该问题，请联系管理员billJiang(QQ:475572229),或者你可以点击下面的按钮回到系统首页";
}
