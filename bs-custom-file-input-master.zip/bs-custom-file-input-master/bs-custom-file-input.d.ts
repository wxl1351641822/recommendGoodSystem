declare const bsCustomFileInput: {
  init(inputSelector?: string, formSelector?: string): void;
  destroy(): void;
};

export default bsCustomFileInput;
